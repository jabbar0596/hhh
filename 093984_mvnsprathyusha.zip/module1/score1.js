function validate()
{
   var isValid=true;
   
   if(!isValidModule())
   {
     isValid=false;
	 alert("please select a Valid module");
	 alert("valid JEE modules are Core Java, Servlet-JSP and Spring");
	 alert("valid .NET modules are C#, ADO.NET and ASP.NET");
   }   
   
   if(isValid)
   {
     display();
   }	 
   
   return isValid;
}

function isValidModule()
{
   selected=false;

   domainName=document.getElementById("selDomain").value;
   moduleName=document.getElementById("selModule").value;
   
   if(domainName=="JEE" && (moduleName=="Core Java" || moduleName=="Servlet-JSP" || moduleName=="Spring"))
   {
      selected=true;
   }
   else if(domainName!="JEE" && (moduleName!="Core Java" && moduleName!="Servlet-JSP" && moduleName!="Spring"))
   {
      selected=true;
   }
   else
   {
      selected=false;
   }   
   return selected;
   }

function getTotalMarks()
   {
    mttMarks=document.getElementById("txtMTT").value;
    mptMarks=document.getElementById("txtMPT").value;
	assignmentMarks=document.getElementById("txtAssignment").value;
    totalScore= (mptMarks*70)/70 + (mttMarks*15)/64 + (assignmentMarks*15)/100
    return totalScore;
	}

function display()
{	 
     total=getTotalMarks();
     if(total >89)
	 {
	  score =5
	  status="Pass"
	  }
	 else if(total >79)
	 {
	  score =4
	  status="Pass"
	  }
 	 else if(total >69)
	 {
	  score =3
	  status="Pass"
	  }
	 else if(total >59)
	 {
	  score =2
	  status="Pass"
	  }
	 else if(total >49)
	 {
	  score =1
	  status="Fail"
	  }
	 else
	 {
	  score =0
	  status="Fail"
	  }

     alert("Total Marks:"+total+"    Score:"+score+"     Status:"+status);
}	 